#include<bits/stdc++.h>
using namespace std;
int ini1,ini2,need,temp1,temp2,dp[100][100];
int minimum(int n, int m, bool maximizing)
{
    if(m>n)
        swap(m,n);

    if(m==0 || n==0)
    {
        if(maximizing)
            return -1;
        else
            return +1;
    }

    if(m==1 || n==1)
    {
        if(maximizing)
            return +1;
        else
            return -1;

    }

    int loop=n/m;

    if(maximizing)
    {
        int mxval=-1e9;

        for(int i=1; i<=loop; i++)
        {
            int eval=minimum(n-i*m,m,false);


            if(eval>mxval)
            {
                ///cout<<"n:"<<n-i*m<<" "<<m<<endl;
                mxval=eval;

                //need=i;

            }
        }

        return mxval;
    }

    else
    {
        int mnval=1e9;

        for(int i=1; i<=loop; i++)
        {
            int eval=minimum(n-i*m,m,true);


            if(eval<mnval)
            {
                mnval=eval;

                dp[n][m]=i,dp[m][n]=i;


            }

        }

        return mnval;
    }

}

int main()
{
    cout<<"-------Playing with natural number--------\n";
    cout<<"Enter two initial number a>b:";
    cin>>ini1>>ini2;
    int step=0;
    cout<<"who will play first:"<<endl;
    cout<<"if computer then press 1 otherwise 0"<<endl;
    int item;
    cin>>item;
    if(item==0)
    step=0;
    else
        step++;


    while(1)
    {
        cout<<"Remaining value :"<<ini1<<' '<<ini2<<endl;
        if(step%2==1)
        {
            if(ini1==0 || ini2==0)
            {
                cout<<"computer lose."<<endl;

                break;
            }

            if(ini1==1 || ini2==1)
            {
                cout<<"you lose."<<endl;

                break;
            }


           cout<<"computer turn : "<<endl;
           minimum(ini1,ini2,false);
             ///cout<<"ans:"<<ans<<endl;
             ///cout<<ini1<<" "<<ini2<<endl;
            ///cout<<"dp:"<<dp[ini1][ini2]<<endl;
            ini1=ini1-dp[ini1][ini2]*ini2;
            if(ini1<ini2)
                swap(ini1,ini2);


        }

        else
        {
            if(ini1==0 || ini2==0)
            {
                cout<<"you lose."<<endl;

                break;
            }

            if(ini1==1 || ini2==1)
            {
                cout<<"computer lose."<<endl;

                break;
            }
            cout<<"your turn: "<<endl;

            cout<<"please enter x(b*x<=a):";

            int val;

            cin>>val;

            ini1=ini1-ini2*val;

            if(ini1<ini2)
                swap(ini1,ini2);

        }

        step++;


    }
    return 0;
}
